<?php
 
namespace App;
 
abstract class Router
{
    public static function routeRequest()
    {
        try
        {
            switch (Request::endpointName()) {
                case '/':
		case '':
		    $endpoint = new EndpointController\Home();
		    break;
                case '/authorinfo':
                case '/authorinfo/':
                    $endpoint = new EndpointController\AuthorInfo();
                    break;

                case '/developer':
                case '/developer/':
                    $endpoint = new EndpointController\Developer();
                    break;
                case '/content':
                case '/content/':
                    $endpoint = new EndpointController\Content();
                    break;
                case '/country':
                case '/country/':
                    $endpoint = new EndpointController\Country();
                    break;
                case '/preview':
                case '/preview/':
                    $endpoint = new EndpointController\Preview();
                    break;
                case '/savedcontent':
                case '/savedcontent/':
                    $endpoint = new EndpointController\SavedContent();
                    break;
                case '/note':
                case '/note/':
                    $endpoint = new EndpointController\Note();
                    break;

		case '/token':
		case '/token/':
   		    $endpoint = new EndpointController\Token();
		    break;
                default:
                    throw new ClientError(404);
                    break; 
            }
        } catch (ClientError $e) {
            $data = ['message' => $e->getMessage()];
            $endpoint = new EndpointController\Endpoint($data);
        }
 
        return $endpoint;
    }
}