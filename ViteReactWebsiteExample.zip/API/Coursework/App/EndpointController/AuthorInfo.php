<?php

namespace App\EndpointController;

class AuthorInfo extends Endpoint
{
    protected $allowedParams = [ "id","country"];
    private $sql = "
	SELECT
 	   author.id,
  	   author.name AS author_name,
  	   affiliation.content,
  	   content.title AS content_title,
  	   affiliation.country,
   	   affiliation.city,
   	   affiliation.institution,
	   content.doi_link
	FROM
 	   Author
	JOIN
 	   Content_has_author 
	ON 
	   author.id = content_has_author.author
	JOIN
	    Affiliation 
	ON
            author.id = Affiliation.author 
	AND 
  	    content_has_author.content = Affiliation.content
	JOIN
	    Content 
	ON 
	    Affiliation.content = content.id
	ORDER BY
	    author_name;";

    private $sqlParams = [];

    public function __construct()
    {
        switch(\App\Request::method()) {
            case 'GET':
                $this->checkAllowedParams();
                $this->buildSQL();

                $dbConn = new \App\Database("db/chi2023.sqlite");
                $data = $dbConn->executeSQL($this->sql, $this->sqlParams); 
                break;
            default:
                throw new \App\ClientError(405);
        }
        parent::__construct($data);
    }
 
 
    private function buildSQL()
    {
        $where = false;
 
        if (isset(\App\Request::params()['id'])) 
        {
            if (!is_numeric(\App\REQUEST::params()['id'])) {
                throw new \App\ClientError(422);
            }
            if (count(\App\Request::params()) > 1) {
                throw new \App\ClientError(422);
            } 
            $this->sql .= " WHERE author.id = :id";
            $this->sqlParams[":id"] = \App\Request::params()['id'];
        }

        if (isset(\App\REQUEST::params()['country']))
        {
            // Use the flag to determine if we need AND or WHERE
            $this->sql .= ($where) ? " AND" : " WHERE";
            $where = true;
            $this->sql .= " affiliation.country = :country";
            $this->sqlParams[':country'] = \App\REQUEST::params()['country'];
        }    }
 
}