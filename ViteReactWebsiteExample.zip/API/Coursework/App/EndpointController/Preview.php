<?php

namespace App\EndpointController;

class Preview extends Endpoint
{
    protected $allowedParams = ["limit"];


    private $sql = "
	SELECT 
    		title, preview_video
	FROM
		content
	WHERE
		preview_video
	IS NOT NULL
	ORDER BY RANDOM()
	;";

    private $sqlParams = [];

    public function __construct()
    {
        switch(\App\Request::method()) {
            case 'GET':
                $this->checkAllowedParams();
		$this->buildSQL();
                $dbConn = new \App\Database("db/chi2023.sqlite");
                $data = $dbConn->executeSQL($this->sql, $this->sqlParams); 
                break;
            default:
                throw new \App\ClientError(405);
        }
 
        parent::__construct($data);
    }
 
private function buildSQL()
{
    $this->sql = "
        SELECT 
            title, preview_video
        FROM
            content
        WHERE
            preview_video IS NOT NULL";

    if (isset(\App\Request::params()['limit'])) 
    {
        $this->sql .= " ORDER BY RANDOM()";
        $this->sql .= " LIMIT :limit";
        $this->sqlParams[":limit"] = \App\Request::params()['limit'];
    }
}}