<?php

namespace App\EndpointController;


class Token extends Endpoint
{
private $sql = "SELECT id, password FROM user WHERE email = :email";
private $sqlParams = [];
    public function __construct() {
 switch(\App\Request::method()) 
{
    case 'GET':
    case 'POST':
        $this->checkAllowedParams();
        $dbConn = new \App\Database("db/user.sqlite");
 
        if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
            throw new \App\ClientError(401);
        }
 
        if (empty(trim($_SERVER['PHP_AUTH_USER'])) || empty(trim($_SERVER['PHP_AUTH_PW']))) {
            throw new \App\ClientError(401);
        }
 
        $this->sqlParams[":email"] = $_SERVER['PHP_AUTH_USER'];
        $data = $dbConn->executeSQL($this->sql, $this->sqlParams);
 
        if (count($data) != 1) {
            throw new \App\ClientError(401);
        }
 
        if (!password_verify($_SERVER['PHP_AUTH_PW'], $data[0]['password'])) {
            throw new \App\ClientError(401);
        }
 
        //* @todo 7. issue token
        $token = $this->generateJWT($data[0]['id']);        
        $data = ['token' => $token];
 
        parent::__construct($data);
        break;
    default:
        throw new \App\ClientError(405);
        break;
}}
	private function generateJWT($id) { 
 
  // 1. Uses the secret key defined earlier
  $secretKey = SECRET;
 
  // 2. Specify what to add to the token payload. 
  $payload = [
	'sub' => $id, 
	'iat' => time(),
	'exp' => strtotime('+30 minutes', time()),
	'iss' => $_SERVER['HTTP_HOST'] ];
      
  // 3. Use the JWT class to encode the token  
  $jwt = \Firebase\JWT\JWT::encode($payload, $secretKey, 'HS256');
  return $jwt;
}}