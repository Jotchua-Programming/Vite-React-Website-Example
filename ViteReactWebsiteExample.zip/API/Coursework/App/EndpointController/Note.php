<?php
 
namespace App\EndpointController;

class Note extends Endpoint 
{
    public function __construct()
    {
        $id = $this->validateToken();
        
        $this->checkUserExists($id);
 
        switch(\App\Request::method()) 
        {
            case 'GET':
                $data = $this->getNote($id);
                break;
            case 'POST':
                $data = $this->postNote($id);
                break;
            case 'DELETE':
                $data = $this->deleteNote($id);
                break;
            default:
                throw new \App\ClientError(405);
                break;
        }
        parent::__construct($data);
    }
 
    /**
     * Same as Favourites endpoint
     */
    private function validateToken()
    {
        $secretkey = SECRET;
                
        $jwt = \App\REQUEST::getBearerToken();
 
        try {
            $decodedJWT = \Firebase\JWT\JWT::decode($jwt, new \Firebase\JWT\Key($secretkey, 'HS256'));
        } catch (\Exception $e) {
            throw new \App\ClientError(401);
        }
 
        if (!isset($decodedJWT->exp) || !isset($decodedJWT->sub)) { 
            throw new \App\ClientError(401);
        }
 
        return $decodedJWT->sub;
    }
 
    /**
     * Check the note exists and do some basic validation
     */
    private function note() 
    {
        if (!isset(\App\REQUEST::params()['note']))
        {
            throw new \App\ClientError(422);
        }
 
        if (mb_strlen(\App\REQUEST::params()['note']) > 255)
        {
            throw new \App\ClientError(422);
        }
 
       $note = \App\REQUEST::params()['note'];
       return htmlspecialchars($note);
    }
 
        // return all notes for the user.
	// this also needs to return the name of the content that the content_id is associated with
	// as this is held in a seperate database, two queries need to be executed and the results merged
	// doi_link will also be retrieved
	// this will be used in the front end to display all the names on the screen so they can be clicked, resulting in a contentid being passed
	
	private function getNote($id)
	{
 	//as we are fetching from two databases, we define them here
 	$dbConnNotes = new \App\Database('db/user.sqlite');
  	$dbConnContent = new \App\Database('db/chi2023.sqlite');
	$result = [];
	

 	// query to retrieve all notes for the defined user
 	$sql = "SELECT * FROM notes WHERE user_id = :id;";
  	$sqlParams = [':id' => $id];
  	$dataNotes = $dbConnNotes->executeSQL($sql, $sqlParams);
	  
	//loop for every instance of datanotes
	//in a usual query, we would just return here but as we are merging two databases with separate fields,
	//that cannot be done
	foreach ($dataNotes as $note) {
   	   	// extract relevant information from the notes result
   	   	$noteText = $note['note'];
		$contentId = $note['content_id'];
		
     	   	// query to retrieve title and doi_link from the content database
     	   	$sqlContent = "SELECT title, doi_link FROM content WHERE id = :content_id";
     	   	$sqlParamsContent = [':content_id' => $contentId];
    	   	$dataContent = $dbConnContent->executeSQL($sqlContent, $sqlParamsContent);

      	 	 // Check if dataContent is not empty before accessing its values
      	 	 if (!empty($dataContent)) {
      	 	     // extract title and data information from the content result
      	  	    $title = $dataContent[0]['title'];
      	  	    $doiLink = $dataContent[0]['doi_link'];
      	 	 } else {
      	    	  // these values should never be null, but if they are, throw a 204 error signifying no results
      	   	  $title = null;
       	    	  $doiLink = null;
		  throw new \App\ClientError(204);
      	  	}

       	 	// combine the results into a single array
       		 $result[] = [
         	 'user_id' => $id,
         	 'content_id' => $contentId,
           	 'note' => $noteText,
           	 'title' => $title,
           	 'doi_link' => $doiLink,
        	];
   	 }

    	return $result;
	}	

    /**
     * This handles both posting a new note and updating an existing note
     * for a film. There can only be one note per film per user.
     */
    private function postNote($id)
    {
        if (!isset(\App\REQUEST::params()['content_id']))
        {
            throw new \App\ClientError(422);
        }
 
        $content_id = \App\REQUEST::params()['content_id'];
        
        if (!is_numeric($content_id))
        {
            throw new \App\ClientError(422);
        }
 
        $note = $this->note();
 
        $dbConn = new \App\Database('db/user.sqlite');
 
        $sqlParams = [':id' => $id, 'content_id' => $content_id];
        $sql = "SELECT * FROM notes WHERE user_id = :id AND content_id = :content_id";
        $data = $dbConn->executeSQL($sql, $sqlParams);
 
        if (count($data) === 0) {
            $sql = "INSERT INTO notes (user_id, content_id, note) VALUES (:id, :content_id, :note)";
        } else {
            $sql = "UPDATE notes SET note = :note WHERE user_id = :id AND content_id = :content_id";
        }
 
        $sqlParams = [':id' => $id, 'content_id' => $content_id, 'note' => $note];
        $data = $dbConn->executeSQL($sql, $sqlParams);
     
        return [];
    }
 
 
    /**
     * Delete note entry
     */
    private function deleteNote($id)
    {
        if (!isset(\App\REQUEST::params()['content_id']))
        {
            throw new \App\ClientError(422);
        }
 
        $content_id = \App\REQUEST::params()['content_id'];
        
        if (!is_numeric($content_id))
        {
            throw new \App\ClientError(422);
        }
 
        $dbConn = new \App\Database('db/user.sqlite');
        $sql = "DELETE FROM notes WHERE user_id = :id AND content_id = :content_id";
        $sqlParams = [':id' => $id, 'content_id' => $content_id];
        $data = $dbConn->executeSQL($sql, $sqlParams);
        return $data;
    }
 
    private function checkUserExists($id)
    {
        $dbConn = new \App\Database('db/user.sqlite');
        $sql = "SELECT id FROM user WHERE id = :id";
        $sqlParams = [':id' => $id];
        $data = $dbConn->executeSQL($sql, $sqlParams);
        if (count($data) != 1) {
            throw new \App\ClientError(401);
        }
    }
}