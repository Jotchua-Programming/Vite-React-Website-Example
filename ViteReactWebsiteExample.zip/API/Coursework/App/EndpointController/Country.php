<?php

namespace App\EndpointController;

class Country extends Endpoint
{
    protected $allowedParams = [];
    private $sql = "
	SELECT
  		country,
   		GROUP_CONCAT(content.title) AS content_titles
	FROM
    		affiliation
	JOIN
 		content
	ON 
  		affiliation.content = content.id
	GROUP BY
   		country
	ORDER BY 
  		country ASC;";

    private $sqlParams = [];

    public function __construct()
    {
        switch(\App\Request::method()) {
            case 'GET':
                $this->checkAllowedParams();
                $dbConn = new \App\Database("db/chi2023.sqlite");
                $data = $dbConn->executeSQL($this->sql, $this->sqlParams); 
                break;
            default:
                throw new \App\ClientError(405);
        }
 
        parent::__construct($data);
    }
 
 
   
}