<?php

namespace App\EndpointController;

class Content extends Endpoint
{
    protected $allowedParams = ["id", "type", "page"];
    private $sql = "
	SELECT
    		content.id,
    		type.name 
	AS
	 type, content.title, content.abstract,
    COALESCE(content_has_award.award, 'No Award') 
	AS 	
		award,content.doi_link
	FROM
    		content
    	JOIN 
		type 
	ON 
		content.type = type.id
    	LEFT JOIN 
		content_has_award 
	ON 
		content.id = content_has_award.content
	ORDER BY
		title ASC;";

    private $sqlParams = [];

    public function __construct()
    {
        switch(\App\Request::method()) {
            case 'GET':
                $this->checkAllowedParams();
                $this->buildSQL();
                $dbConn = new \App\Database("db/chi2023.sqlite");
                $data = $dbConn->executeSQL($this->sql, $this->sqlParams); 
                break;
            default:
                throw new \App\ClientError(405);
        }
 
        parent::__construct($data);
    }
 
 
    private function buildSQL()
    {
        $where = false;
 
        if (isset(\App\Request::params()['id'])) 
        {
            if (!is_numeric(\App\REQUEST::params()['id'])) {
                throw new \App\ClientError(422);
            }
            if (count(\App\Request::params()) > 1) {
                throw new \App\ClientError(422);
            } 
            $this->sql .= " WHERE content.id = :id";
            $this->sqlParams[":id"] = \App\Request::params()['id'];
        }
    if (isset(\App\Request::params()['type']))
    {
        $this->sql .= $where ? " AND" : " WHERE";
        $where = true;
        $this->sql .= " type.name LIKE :type";
        $this->sqlParams[':type'] = \App\Request::params()['type'] . "%";
    }

    if (isset(\App\Request::params()['page']))
    {
        $this->sql .= $where ? " AND" : " WHERE";
        $where = true;
        $this->sql .= " page LIKE :page";
        $this->sqlParams[':page'] = \App\Request::params()['page'] . "%";
    }
 
    }
 
}