<?php

namespace App\EndpointController;

class Developer extends Endpoint
{
    public function __construct()
    {
        switch(\App\Request::method()) {
            case 'GET':
                $this->checkAllowedParams();
                $data[] = [
                    'id' => "001",
                    'name' => "Joshua Swinburne",
                ];
                break;
            default:
                throw new \App\ClientError(405);
        }
        parent::__construct($data);
    }
}