<?php
 
namespace App\EndpointController;
 
class SavedContent extends Endpoint 
{

private function validateToken()
{

  $secretkey = SECRET;    
        
        $jwt = \App\Request::getBearerToken();  
    
 	try {
  		$decodedJWT = \Firebase\JWT\JWT::decode($jwt, new \Firebase\JWT\Key($secretkey, 'HS256'));
	} catch (Exception $e) {
  		throw new ClientError(401);
	}return $decodedJWT->sub;
}

public function __construct()
{
    $id = $this->validateToken();
     
        switch(\App\Request::method()) 
        {
            case 'GET':
                $data = $this->getSavedContent($id);
                break;
            case 'POST':
                $data = $this->postSavedContent($id);
                break;
            case 'DELETE':
                $data = $this->deleteSavedContent($id);
                break;
            default:
                throw new \App\ClientError(405);
                break;
        }
        parent::__construct($data);
    }
private function getSavedContent($id)
{
    $dbConn = new \App\Database('db/user.sqlite');
    $sql = "SELECT content_id FROM saved_content WHERE user_id = :id";
    $sqlParams = [':id' => $id];
    $data = $dbConn->executeSQL($sql, $sqlParams);
    return $data;
}

private function postSavedContent($id)
{
    if (!isset(\App\REQUEST::params()['content_id'])) {
        throw new \App\ClientError(422);
    }

    $content_id = \App\REQUEST::params()['content_id'];

    if (!is_numeric($content_id)) {
        throw new \App\ClientError(422);
    }

    $dbConn = new \App\Database('db/user.sqlite');

    $sqlParams = [':id' => $id, 'content_id' => $content_id];
    $sql = "SELECT * FROM saved_content WHERE user_id = :id AND content_id = :content_id";
    $data = $dbConn->executeSQL($sql, $sqlParams);

    if (count($data) === 0) {
        $sql = "INSERT INTO saved_content (user_id, content_id) VALUES (:id, :content_id)";
        $data = $dbConn->executeSQL($sql, $sqlParams);
    }

    return [];
}
    private function deleteSavedContent($id)
    {
        if (!isset(\App\REQUEST::params()['content_id']))
        {
            throw new \App\ClientError(422);
        }
        
        $content_id = \App\REQUEST::params()['content_id'];
 
 
        if (!is_numeric($content_id))
        {
            throw new \App\ClientError(422);
        }
        
        $content_id = \App\REQUEST::params()['content_id'];
 
 
        $dbConn = new \App\Database('db/user.sqlite');
        $sql = "DELETE FROM saved_content WHERE user_id = :id AND content_id = :content_id";
        $sqlParams = [':id' => $id, 'content_id' => $content_id];
        $data = $dbConn->executeSQL($sql, $sqlParams);
        return $data;
    }
}