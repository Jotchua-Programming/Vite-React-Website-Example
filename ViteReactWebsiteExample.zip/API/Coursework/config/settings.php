<?php
define('BASEPATH', '/Coursework');
define('CHI2023_DATABASE', 'db/chi2023.sqlite');
define('USER_DATABASE', 'db/user.sqlite');
define('SECRET', 'HIDMYSECRETKEY'); 