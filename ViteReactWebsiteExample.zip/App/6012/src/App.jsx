import { useEffect, useState } from 'react'
import { Routes, Route } from "react-router-dom"
import Home from "./pages/Home"
import Header from "./components/Header"
import Content from "./pages/Content"
import Country from "./pages/Country"
import Developer from "./pages/Developer"
import AuthorAndAffiliation from "./pages/AuthorAndAffiliation"
import NotFound from "./pages/NotFound"
import Footer from "./components/Footer"
import SignIn from "./components/SignIn"
import Note from "./pages/Note"

 
 
function App() {
    const [signedIn, setSignedIn] = useState(false)
    const [SavedContent, setSavedContent] = useState([])
     return (
        <>
    <SignIn signedIn={signedIn} setSignedIn={setSignedIn} SavedContent = {SavedContent} setSavedContent={setSavedContent}/>

    <Header />
    <Routes>
        <Route path="/" element={<Home signedIn={signedIn} setSignedIn={setSignedIn}/>} />
        <Route path="/Developer" element = {<Developer signedIn={signedIn} setSignedIn={setSignedIn}/>}/>
        <Route path="/Content" element={<Content signedIn={signedIn} setSignedIn={setSignedIn}/>} />
        <Route path="/Country" element={<Country signedIn={signedIn} setSignedIn={setSignedIn}/>} />
        <Route path="/AuthorAndAffiliation" element={<AuthorAndAffiliation signedIn={signedIn} setSignedIn={setSignedIn} />} />
        <Route path="/note" element={<Note signedIn={signedIn} setSignedIn={setSignedIn}/>} />
        <Route path="/*" element={<NotFound signedIn={signedIn} setSignedIn={setSignedIn}/>} />
      </Routes>
    <Footer />
        </>
    )
}
 
export default App