import { Link } from 'react-router-dom';

function Header() {
    return (
        <nav className="bg-gray-400 text-black-800 border-double border-2 border-slate-800 ">
        <ul className="flex flex-col md:flex-row justify-evenly items-center text-xl">
            <>
            
        
            <li><Link to="/">🏠 Home</Link></li>
            <li><Link to="/developer">🧑🏽 Developer</Link></li>
            <li><Link to="/content">📒 Publications</Link></li>
            <li><Link to="/authorandaffiliation">✒️ Authors</Link></li>
            <li><Link to="/country">🌎 Countries</Link></li>
            <li><Link to ="/note">📝 Notes</Link></li>
            </>
        </ul>
        </nav>
    )
}
 
export default Header