import { Link } from "react-router-dom";
 

function Footer() {
    return (
        <nav className="bg-gray-400 text-black-800 border-double border-2 border-slate-800 ">
        <ul className="flex flex-col md:flex-row justify-evenly items-center text-xl"></ul>
        <>
            <p>Joshua Swinburne</p>
            <p></p>
            <p>Coursework Assignment for Web Application Integration</p>
        </>
        </nav>
    )
}
 
export default Footer