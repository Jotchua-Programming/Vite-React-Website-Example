import { useState, useEffect } from 'react';


function SignIn(props) {
    //sets constants used throughout the program
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorSigningIn, setErrorSigningIn] = useState(false);
    const [tokenExpired, setTokenExpiry] =useState('false')
    const inputColor = errorSigningIn ? 'bg-red-100' : 'bg-slate-100';

    //private function that decodes the token splits the token into segments
    //'.' is used, as that is what tokens use to split up their segments
    //this is only used to check if the token has expired, and is not passed anywhere else
    const parseJWT = (token) => {
        try {
          return JSON.parse(atob(token.split('.')[1]));
        } catch (e) {
          return null;
        }
      };
    //every time a page is refreshed, moved to or refreshed, check if the login is still valid
    useEffect(
        () => {
            //sets the browsers saved token to a constant
            const storedToken = localStorage.getItem('token');
            //does a token exist?
            if (storedToken) {
                //if so, decode it
                const decodedJWT = parseJWT(storedToken);
                //check if there is a decoded token
                //if there is not, it cannot be decoded and the user cannot be signed in
                //this prevents someone from deleting their token for whatever reason and the code trying to read a null token
              if(decodedJWT){
              if(decodedJWT.exp * 1000< Date.now())
              {
                //if so, sign the user out, and set the token to expired
                props.setSignedIn(false)
                setTokenExpiry(true)
              }
              //if there is a token, and it has not expired
              //sign the user in, and set the token to valid
              else{
                props.setSignedIn(true)
                setTokenExpiry(false)
                getSavedContent()
              }
        }
        }//if there is no stored token, ensure the user is signed out
        //token expiry is set to false here to reset it to its original state
        else{
            props.setSignedIn(false)
            setTokenExpiry(false)
        }
        }
    
        , []
    )
    const getSavedContent = () => {
        fetch('HIDDENWEBPAGE/savedcontent',
          {
            method: 'GET',
            headers: new Headers({ "Authorization": "Bearer "+localStorage.getItem('token') })
          })
         .then(response => {
            return response.json()
         })
         .then(data => {
            const flattenedData = data.map((SavedContent) => SavedContent.content_id)
            props.setSavedContent(flattenedData)
         })
       }

    const signIn = () => {
        //uses the btoa library to encode the username and password
        const encodedString = btoa(username + ':' + password)
        fetch('HIDDENWEBPAGE/token',
        {
            method: 'GET',
            headers: new Headers( { "Authorization": "Basic " + encodedString })
          }
        )
        .then(response => {
            //if okay, sign the user in, state there is no sign in error,
            //state the token has not expired and get their saved content
            if(response.status === 200) {
                props.setSignedIn(true)
                setErrorSigningIn(false)
                setTokenExpiry(false)
                getSavedContent()
            } else {
                //if failed, inform the program there was a sign in error
                setErrorSigningIn(true)
            }
            return response.json()
        })
        .then(data => {
            if (data.token) {
                localStorage.setItem('token', data.token)
              }getSavedContent()
        })
        .catch(error => console.log(error))
    }
    //once the sign out button is clicked, remove the username and password, sign them out,
    //reset the token expiry value and purge the token from the browser
    const signOut = () => {
        setUsername('')
        setPassword('')
        props.setSignedIn(false)
        setTokenExpiry(false)
        localStorage.removeItem('token');
    }
    //at the end of this function, returns text if the login was invalid, or the token has expired

    return (
      
        <div className='bg-slate-800 p-2 text-md text-right'>
            <h1 className='text-white text-3xl text-left'>CHI 2023 Publication Website</h1>
            { 
            !props.signedIn && <div>
                <input 
                 type="text" 
                 placeholder='username' 
                 className={'p-1 mx-2 rounded-md ' + inputColor}
                 value={username}
                 onChange={(e) => setUsername(e.target.value)}
                />
                <input 
                 type="password" 
                 placeholder='password' 
                 className={'p-1 mx-2 rounded-md ' + inputColor}
                 value={password}
                 onChange={(e) => setPassword(e.target.value)}
                />
                <input 
                 type="submit" 
                 value='Sign In' 
                 className='py-1 px-2 mx-2 bg-green-300 hover:bg-green-500 rounded-md'
                 onClick={signIn}
                />
            </div>
            }
            { props.signedIn && <div>
                <input 
                 type="submit" 
                 value='Sign Out' 
                 className='py-1 px-2 mx-2 bg-red-300 hover:bg-red-500 rounded-md'
                 onClick={signOut}
                />
            </div>
            }
            
            {errorSigningIn && <p className='text-red-900'>Invalid username/password</p>}
            {tokenExpired && <p className='text-red-900'>Login Session Expired. Please Sign In Again</p>}
            
        </div>
    )
}
 
export default SignIn;