import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function Search(props) {
    return (
        <input type="text" value={props.search} onChange={props.handleSearch} placeholder = "Search for a publication"/>
    )
}
 
 
function Content(props) {
    const [visible, setVisible] = useState(false)

    {/*
        const Save = () => {
            let formData = new FormData();
            formData.append('content_id', props.contents.id)
              
            fetch('HIDDENWEBPAGE/savedcontent',
              {
                method: 'POST',
                headers: new Headers({"Authorization":"Bearer "+localStorage.getItem('token')}),
                body: formData,
              }
            )
            .then(res => {
                  if ((res.status === 200) || (res.status === 204)) {
                      props.setSavedContent([...props.SavedFilms, props.contents.id])
                  }
            })
        }
        const unSave = () => {
            fetch('HIDDENWEBPAGE'+props.contents.id,
            {
             method: 'DELETE',
             headers: new Headers({"Authorization": "Bearer "+localStorage.getItem('token')}),
            }
           )
           .then(res => {
              if ((res.status === 200) || (res.status === 204)) {
                  // Use the filter method to remove the film_id(s) from the favourites array
                  props.setSavedContent(props.SavedContent.filter(
                    fav => fav !== props.contents.id
                  ))
              }
           })
        }
        //code to check if SavedContent includes the items id
        //if it does, show the heart to indicate it has been saved
        //if it does not, show the blank box
        //on click, the heart triggers the unsave function, which removes it from SavedContent and changes it to the box
        //clicking the box triggers the save function, adding it to the array and changing it to the heart
     const isSaved = (props.SavedContent.includes(props.contents.id)) 
        ? <span onClick = {unSave}>💘</span>
    : <span onClick = {Save}>🔲</span>*/}

    //toggles an icon on and off to indicate if an item has been saved or not
    const[displayText, setDisplayText] = useState('🔲')
    const toggleSaveButton = (ContentTitle) => {
        setDisplayText((prevDisplayText) => (prevDisplayText === '💘' ? '🔲' : '💘'));
    }
    //on click, display all the information about the target item
    return (
        
        <div className='bg-white h-auto m-2 p-2 rounded-md'>
        
            <h2 onClick={() => setVisible( visible => !visible )}>{props.contents.title} <p className='grow text-xl text-right'></p></h2>
            <p className='grow text-3xl text-right' onClick={(event) => toggleSaveButton(event)}>{displayText}</p>
            
            {visible && <>
                <p>Publication Type: {props.contents.type}</p>
                <p>Amount of Awards: {props.contents.award}</p>
                <p><Link to={"" + props.contents.doi_link} className="font-medium text-blue-600 dark:text-blue-500 hover:underline">View this Publication</Link></p>
                <p>Abstract: {props.contents.abstract}</p>
                
            </>}
        </div>
    )
}
function ContentList(props) {
    const [contents, setContent] = useState([])
    const [search, setSearch] = useState('')
    const [selectType, setSelectType] = useState('')
    const [page, setPage] = useState(1)
 
 
    useEffect( () => {
        fetchData()
    },[])
 
 
    const handleResponse = (response) => {
        if (response.status === 200) {
            return response.json()
        } else {
            throw new Error("invalid response: " + response.status)
        }
    }
     
    const handleJSON = (json) => {
        if (json.constructor === Array) {
            setContent(json)
        } else {
            throw new Error("invalid JSON: " + json)
        }
    }
     
    const fetchData = () => { 
        fetch('HIDDENWEBPAGE/content')
        .then( response => handleResponse(response) )
        .then( json => handleJSON(json) )
        .catch( err => { console.log(err.message) })
    }
 
    const startOfPage = (page - 1) * 20
    const endOfPage = startOfPage + 20
 
    // function used for filtering films    
    const searchContents = (contents) => {
        const foundInTitle = contents.title.toLowerCase().includes(search.toLowerCase())
        return foundInTitle
    }
 
 
    const selectContentType = (contents) => {
        if (selectType === '') {
            return true
        } else {
            return contents.type === selectType
        }
    }
  
    // filters out data based on the criteria the user entered
    const contentsJSX = contents
        .filter(selectContentType)
        .filter(searchContents)
        .slice(startOfPage, endOfPage)
        .map( 
            (contents, i) => <Content key={i + contents.title} count={i} contents={contents} signedIn = {props.signedIn} SavedContent = {props.SavedContent} setContent = {props.setContent} />
        ) 
        

    
    const lastPage = contents.length === 0 || contentsJSX.length === 0
    const firstPage = page <= 1
      
    // Functions to change the page
    const nextPage = () => {
        if (lastPage === false) {
            setPage( page => page + 1 )
        }
    }
      
      
    // Functions to change the page
    const previousPage = () => {
        if (firstPage === false) {
            setPage( page => page - 1 )
        }
    }
      
    const prevDisabled = firstPage ? 'disabled' : '';
    const nextDisabled = lastPage ? 'disabled' : '';
 
    // update state when the search input changes
    const handleSearch = (event) => {
        setSearch(event.target.value)
    }
 
 
    const handleSelectType = (event) => {
        setSelectType(event.target.value)
    }
        //creates a new array holding all of the unique category names sorted in alphabetical order
const uniqueTypes = [...new Set(contents.map(({ type }) => type))].sort()
    return (
        <div className="flex flex-col items-center justify-center min-h-screen">
            <h1 className='text-2xl font-bold'>Publication Listings</h1>
            <button className='py-1 px-2 mx-2 bg-gray-300 hover:bg-gray-400 rounded-md mx-auto' onClick={previousPage} disabled={prevDisabled}>
            ⬅️ Previous
        </button>
        <button className='py-1 px-2 mx-2 bg-gray-300 hover:bg-gray-400 rounded-md mx-auto' onClick={nextPage} disabled={nextDisabled}>
          Next ➡️
        </button>
            <Search search={search} handleSearch={handleSearch} />
            <div >
                <label lassName="mx-auto">Type
                    <select value={selectType} onChange={handleSelectType}>
                        <option value="">Any</option>
                        {uniqueTypes.map((type, index) =>(
                            <option key ={index} value = {type}>{type}</option>
                        ))
                        }
                    </select>
                </label>
                
            </div>
            <div className="grid md:grid-cols-1 lg:grid-cols-1">
            {contentsJSX}
            </div>
            
        </div>
    )
}
 
export default ContentList