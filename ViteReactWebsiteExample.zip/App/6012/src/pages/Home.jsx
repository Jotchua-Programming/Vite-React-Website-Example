import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function VideoShow(props)
{
    return (
        <div className='bg-white h-auto m-2 p-2 rounded-md text-center'>
        <section>
            <ul>
                <li>
                    <h2>{props.video.title}</h2>
                    <h3><Link to={"" + props.video.preview_video} className="text-9xl">▶️</Link></h3>
                </li>
            </ul>
          
        </section>
        </div>
      )
}



function Home() {
    const [limit, setLimit] = useState('1')
    const [videoDB, setVideoDB] = useState([])

    useEffect( () => {
        fetchData()
    },[])


    const handleResponse = (response) => {
        if (response.status === 200) {
            return response.json()
        } else {
            throw new Error("invalid response: " + response.status)
        }
    }
     
    const handleJSON = (json) => {
        if (json.constructor === Array) {
            setVideoDB(json)
        } else {
            throw new Error("invalid JSON: " + json)
        }
    }
     
    const fetchData = () => { 
        fetch('HIDDENWEBPAGE/preview?limit='+limit)
        .then( response => handleResponse(response) )
        .then( json => handleJSON(json) )
        .catch( err => { console.log(err.message) })
    }

    const videoDBJSX = videoDB
    .map( 
        (videoDB, i) => <VideoShow key={i + videoDB.title} count={i} video={videoDB} /> 
    ) 

    return (
        <div className="flex flex-col items-center justify-center min-h-screen">
            <h1 className='text-2xl font-bold'>Welcome to the home page</h1>
            <p>This year, the CHI conference was held in Hamburg, Germany</p>
            <p>There were over 1500 papers submitted this year!</p>
            <p>Here is a video of one of many presented this year;</p>
            {videoDBJSX}
        </div>
    )
}
 
export default Home