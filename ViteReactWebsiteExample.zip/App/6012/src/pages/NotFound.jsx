import { Link } from "react-router-dom";
import ErrorImage from '../assets/ErrorImage.jpg'

function NotFound() {
    return (
        <>            
            <h1>Error 404</h1>
            <p>Page not found</p>
            <a href="ErrorImage.jpg" target="_blank">
                <img src = {ErrorImage} className="Error" alt="Error Image" />
            </a>

            <p> <Link to="/">Return to menu</Link></p>
        </>
    )
}
 
export default NotFound