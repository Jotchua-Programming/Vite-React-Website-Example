import { useEffect, useState } from 'react'

function Developer() {
    const [developer, setDeveloper] = useState([])
 
 
    useEffect( () => {
        fetchData()
    },[])
 
 
    const handleResponse = (response) => {
        if (response.status === 200) {
            return response.json()
        } else {
            throw new Error("invalid response: " + response.status)
        }
    }
     
    const handleJSON = (json) => {
        if (json.constructor === Array) {
            setDeveloper(json)
        } else {
            throw new Error("invalid JSON: " + json)
        }
    }
     
    const fetchData = () => { 
        fetch('HIDDENWEBPAGE/developer')
        .then( response => handleResponse(response) )
        .then( json => handleJSON(json) )
        .catch( err => { console.log(err.message) })
    }



 
    return (
        <>
            <h1>Developer</h1>
            {developer.map((developer, i) => (
                <div key={i}>
                    <p>ID: {developer.id}</p>
                    <p>Name: {developer.name}</p>
                </div>
            ))}
        </>
    )
}
 
export default Developer