import { useEffect, useState } from 'react'
 
function Country(props) { 
    const [visible, setVisible] = useState(false)
    //allows clicking of a country to show publications that originate from there
    //the array of content titles must be converted into a set, as there are multiple records of each publication
    //this is due to some publications having many country associations
    return (
        <section className='bg-white h-auto m-2 p-2 rounded-md'>
            <h2 onClick={() => setVisible( visible => !visible )}>{props.country.country} </h2>
            {visible && <>
                {[...new Set(props.country.content_titles.split(','))].map((content_titles,i) => (
                        <p key={i}>{content_titles}</p>
                    ))}
            </>}
        </section>
    )
}

function CountryList() {
    const [country, setCountry] = useState([])
 
 
    useEffect( () => {
        fetchData()
    },[])
 
 
    const handleResponse = (response) => {
        if (response.status === 200) {
            return response.json()
        } else {
            throw new Error("invalid response: " + response.status)
        }
    }
     
    const handleJSON = (json) => {
        if (json.constructor === Array) {
            setCountry(json)
        } else {
            throw new Error("invalid JSON: " + json)
        }
    }
     
    const fetchData = () => { 
        fetch('HIDDENWEBPAGE/country')
        .then( response => handleResponse(response) )
        .then( json => handleJSON(json) )
        .catch( err => { console.log(err.message) })
    }
    
    const countryJSX = country.map((country, i) => <Country key={i + country.country} count={i} country={country} /> 
    ) 

    return (
        <>
            <h1>Countries that Participated in this Years CHI 2023 Conference</h1>
            <p>Click a country to see the publications from each country</p>
            <div className="grid md:grid-cols-1 lg:grid-cols-1">
            {countryJSX}
            </div>
        </>
    )
}
 
export default CountryList