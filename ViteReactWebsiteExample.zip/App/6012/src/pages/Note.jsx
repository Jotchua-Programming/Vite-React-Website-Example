import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function Search(props) {
    return (
        <input type="text" value={props.search} onChange={props.handleSearch} placeholder = "Search for a note"/>
    )
}
 
 
function Note(props) {
    const [visible, setVisible] = useState(false)


/*
        const SaveNote = () => {
            let formData = new FormData();
            formData.append('content_id', props.note.id)
              
            fetch('HIDDENWEBPAGE/note',
              {
                method: 'POST',
                headers: new Headers({"Authorization":"Bearer "+localStorage.getItem('token')}),
                body: formData,
              }
            )
            .then(res => {
                  if ((res.status === 200) || (res.status === 204)) {
                      setNotes([...notes.user_id, notes.content_id, notes.note])
                  }
            })
        }
    
        //sends an id to the api to compare with a record and delete it
        //as the api handles this process, the DELETE request is all that needs to be executed
        const DeleteNote = () => {
            fetch('HIDDENWEBPAGE/note?content_id='+props.notes.content_id,
            {
             method: 'DELETE',
             headers: new Headers({"Authorization": "Bearer "+localStorage.getItem('token')}),
            }
            )
        }

        //posts the new/amended data to the api
        //sends the user id, content id and the note
        const EditNote = () => {
            fetch('HIDDENWEBPAGE/note?id= ' + props.notes.user_id+'&content_id='+props.notes.content_id+'&note'+props.notes.notes,
            {
             method: 'POST',
             headers: new Headers({"Authorization": "Bearer "+localStorage.getItem('token')}),
            }
            )
        }*/


    //equivilant of code for deleting and posting content, showing some of the general concepts
    const handleConfirm =() =>
    {
        <p>confirm</p>
    }

    const handleDelete =() =>
    {
        <p>delete</p>
        
    }

    const handleEdit =() =>
    {
        <p>edit</p>
    }
    return (
            <div className='bg-white h-auto m-2 p-2 rounded-md'>
            <h2 onClick={() => setVisible( visible => !visible )}>{props.notes.title}</h2>
            
            {visible && <>
                <p className='grow text-xl text-right'>
                <span onClick = {handleConfirm}>✅</span>
                <span onClick = {handleDelete}>🗑️</span>
                <span onClick = {handleEdit}>✏️</span></ p>
                <p>Note: {props.notes.note}</p>
                <p><Link to={"" + props.notes.doi_link}className="font-medium text-blue-600 dark:text-blue-500 hover:underline">View this Publication</Link></p>
                
            </>}
        </div>
    )
}
function NoteList(props) {
    const [search, setSearch] = useState('')
    const [page, setPage] = useState(1)
 
 
    useEffect( () => {
        
    },[])
    /*
    const handleResponse = (response) => {
        if (response.status === 200) {
            return response.json()
        } else {
            throw new Error("invalid response: " + response.status)
        }
    }
     
    const handleJSON = (json) => {
        if (json.constructor === Array) {
            console.log(json)
            setNote(json)
        } else {
            throw new Error("invalid JSON: " + json)
        }
    }
     
    const fetchData = () => { 
        fetch('HIDDENWEBPAGE/note')
        .then( response => handleResponse(response) )
        console.log(json)
        .then( json => handleJSON(json) )
        .catch( err => { console.log(err.message) })
    }*/

    //this is data returned from the sql query from postman where user_id=1
    //currently hardcoded in due to the loss of University webpage functionality
    //it is what the program needs to get to operate, and will be used to show how the code works
    const [notesArray, setNotesArray] = useState([
        
            
                {
                    user_id: 1,
                    content_id: 96527,
                    note: "note for contentid 96527",
                    title: "Engaging Passers-by with Rhythm: Applying Feedforward Learning to a Xylophonic Media Architecture Facade",
                    doi_link: "https://doi.org/10.1145/3544548.3580761"
                },
                {
                    user_id: 1,
                    content_id: 96361,
                    note: "note for contentid 96361",
                    title: "Tactile Symbols with Continuous and Motion-Coupled Vibration: An Exploration of using Embodied Experiences for Hermeneutic Design",
                    doi_link: "https://doi.org/10.1145/3544548.3581356"
                },
                {
                    user_id: 1,
                    content_id: 96155,
                    note: "note for contentid 96155",
                    title: "The Effects of Body Location and Biosignal Feedback Modality on Performance and Workload using Electromyography in Virtual Reality",
                    doi_link: "https://doi.org/10.1145/3544548.3580738"
                },
                {
                    user_id: 1,
                    content_id: 96134,
                    note: "note for contentid 96134",
                    title: "AVscript: Accessible Video Editing with Audio-Visual Scripts",
                    doi_link: "https://doi.org/10.1145/3544548.3581494"
                },
                {
                    user_id: 1,
                    content_id: 96115,
                    note: "note for contentid 96115",
                    title: "WESPER: Zero-shot and Realtime Whisper to Normal Voice Conversion for Whisper-based Speech interactions",
                    doi_link: "https://doi.org/10.1145/3544548.3580706"
                },
                {
                    user_id: 1,
                    content_id: 96042,
                    note: "note for contentid 96042",
                    title: "Through Their Eyes and In Their Shoes: Providing Group Awareness During Collaboration Across Virtual Reality and Desktop Platforms",
                    doi_link: "https://doi.org/10.1145/3544548.3581093"
                },
                {
                    user_id: 1,
                    content_id: 95961,
                    note: "note for contentid 95961",
                    title: "Enhancing Blind Visitor's Autonomy in a Science Museum Using an Autonomous Navigation Robot",
                    doi_link: "https://doi.org/10.1145/3544548.3581220"
                },
                {
                    user_id: 1,
                    content_id: 95894,
                    note: "note for contentid 95894",
                    title: "Do You Mind? User Perceptions of Machine Consciousness",
                    doi_link: "https://doi.org/10.1145/3544548.3581296"
                },
                {
                    user_id: 1,
                    content_id: 95771,
                    note: "note for contentid 95771",
                    title: "Understanding Moderators' Conflict and Conflict Management Strategies with Streamers in Live Streaming Communities",
                    doi_link: "https://doi.org/10.1145/3544548.3580982"
                },
                {
                    user_id: 1,
                    content_id: 96579,
                    note: "note for contentid 96579",
                    title: "Augmenting Human Cognition with an AI-Mediated Intelligent Visual Feedback",
                    doi_link: "https://doi.org/10.1145/3544548.3580905"
                },
                {
                    user_id: 1,
                    content_id: 98780,
                    note: "note for contentid 98780",
                    title: "Trust Issues with Trust Scales: Examining the Psychometric Quality of Trust Measures in the Context of AI",
                    doi_link: "https://doi.org/10.1145/3544549.3585808"
                },
                {
                    user_id: 1,
                    content_id: 98790,
                    note: "note for contentid 98790",
                    title: "Can Cross-Reality Help Nonspeaking Autistic People Transition to AR Typing?",
                    doi_link: "https://doi.org/10.1145/3544549.3585859"
                },
                {
                    user_id: 1,
                    content_id: 98800,
                    note: "note for contentid 98800",
                    title: "Evaluating Accessible Navigation for Blind People in Virtual Environments",
                    doi_link: "https://doi.org/10.1145/3544549.3585813"
                },
                {
                    user_id: 1,
                    content_id: 98876,
                    note: "note for contentid 98876",
                    title: "How Can We Design for Gender-Neutrality in Games? - A Case Study With Children Using Gameplay Rehearsals",
                    doi_link: "https://doi.org/10.1145/3544549.3585637"
                },
                {
                    user_id: 1,
                    content_id: 98938,
                    note: "note for contentid 98938",
                    title: "Respecting, Facilitating and Recognising Children's Contributions in HCI",
                    doi_link: "https://doi.org/10.1145/3544549.3574167"
                },
                {
                    user_id: 1,
                    content_id: 99016,
                    note: "note for contentid 99016",
                    title: "Disagreement, Agreement and Elaboration in Crowdsourced Deliberation: Ideation Through Elaborated Perspectives",
                    doi_link: "https://doi.org/10.1145/3544549.3585708"
                },
                {
                    user_id: 1,
                    content_id: 99042,
                    note: "note for contentid 99042",
                    title: "Dimensional Alt text: Enhancing Spatial Understanding through Dimensional Layering of Image Descriptions for Screen Reader Users",
                    doi_link: "https://doi.org/10.1145/3544549.3585706"
                },
                {
                    user_id: 1,
                    content_id: 99081,
                    note: "note for contentid 99081",
                    title: "Sympathetic Activation in Deadlines of Deskbound Research - A Study in the Wild",
                    doi_link: "https://doi.org/10.1145/3544549.3585585"
                },
                {
                    user_id: 1,
                    content_id: 99157,
                    note: "note for contentid 99157",
                    title: "Designing Accessible Visualizations for People with Intellectual and Developmental Disabilities",
                    doi_link: "https://doi.org/10.1145/3544549.3577048"
                },

                {
                    user_id: 1,
                    content_id: 99217,
                    note: "note for contentid 99217",
                    title: "Designing for In-Home Long-Term Family-Robot Interactions: Family Preferences, Connection Making, and Privacy",
                    doi_link: "https://doi.org/10.1145/3544549.3577035"
                },
            
                {
                    user_id: 1,
                    content_id: 101898,
                    note: "note for contentid 101898",
                    title: "Flowboard: How Seamless, Live, Flow-Based Programming Impacts Learning to Code for Embedded Electronics",
                    doi_link: "https://doi.org/10.1145/3533015"
                },
                {
                    user_id: 1,
                    content_id: 115213,
                    note: "note for contentid 115213",
                    title: "Agapet: Supporting A Responsible Adoption Process for Stray and Abandoned Pets in Urban Areas",
                    doi_link: "https://doi.org/10.1145/3544549.3583845"
                },
                {
                    user_id: 1,
                    content_id: 115218,
                    note: "note for contentid 115218",
                    title: "Towards a Markerless 3D Pose Estimation Tool",
                    doi_link: "https://doi.org/10.1145/3544549.3583950"
                },
                {
                    user_id: 1,
                    content_id: 115220,
                    note: "note for contentid 115220",
                    title: "Exploring Computational Thinking Practices and Gestures in the Context of Matrix Math",
                    doi_link: "https://doi.org/10.1145/3544549.3583944"
                },
                {
                    user_id: 1,
                    content_id: 99194,
                    note: "note for contentid 99194",
                    title: "Accessibility Evaluation of IoT Android Mobile Companion Apps",
                    doi_link: "https://doi.org/10.1145/3544549.3585652"
                },
                {
                    user_id: 1,
                    content_id: 99075,
                    note: "note for contentid 99075",
                    title: "AutoMate - an Empathic First-Aid Communication System to Reduce the Bystander Effect in Car Accidents",
                    doi_link: "https://doi.org/10.1145/3544549.3585777"
                },
                {
                    user_id: 1,
                    content_id: 98966,
                    note: "note for contentid 98966",
                    title: "Designing an Algal Relay Computer: A Critical Orientation in Exploring More-than-Human Temporality",
                    doi_link: "https://doi.org/10.1145/3544549.3585874"
                },
                {
                    user_id: 1,
                    content_id: 98890,
                    note: "note for contentid 98890",
                    title: "Create Effective and Responsible AI User Experiences with The Human-AI Experience (HAX) Toolkit",
                    doi_link: "https://doi.org/10.1145/3544549.3574191"
                },
                {
                    user_id: 1,
                    content_id: 98835,
                    note: "note for contentid 98835",
                    title: "CatHill: Emotion-Based Interactive Storytelling Game as a Digital Mental Health Intervention",
                    doi_link: "https://doi.org/10.1145/3544549.3585639"
                }
        ]
      )
 
    const startOfPage = (page - 1) * 20
    const endOfPage = startOfPage + 20
 
    // function used for filtering notes
    //done by the content title
    //in a setting where a user is intensely using this system, having several hundred records,
    //it will be near impossible to find anything since the search finds entries similar to the input
    const searchNotes = (note) => {
        const foundInTitle = note.title.toLowerCase().includes(search.toLowerCase())
        return foundInTitle
    }
  
    const notesJSX = notesArray
        .filter(searchNotes)
        .slice(startOfPage, endOfPage)
        .map( 
            (note, i) => <Note key={i + note.title} count={i} notes={note} signedIn = {props.signedIn}/>)
          
            
        
    
    const lastPage = notesArray.length === 0 || notesJSX.length === 0; // Check for both Author and AuthorJSX
    const firstPage = page <= 1;
      
    // Functions to change the page
    const nextPage = () => {
        if (lastPage === false) {
            setPage( page => page + 1 )
        }
    }
      
      
    // Functions to change the page
    const previousPage = () => {
        if (firstPage === false) {
            setPage( page => page - 1 )
        }
    }
      
    const prevDisabled = firstPage ? 'disabled' : '';
    const nextDisabled = lastPage ? 'disabled' : '';
 
    // update state when the search input changes
    const handleSearch = (event) => {
        setSearch(event.target.value)
    }

    return (
        <>
        <div className="flex flex-col items-center justify-top min-h-screen">
            <h1 className='text-2xl font-bold'>Your Notes</h1>
            <Search search={search} handleSearch={handleSearch} />
            <button className='py-1 px-2 mx-2 bg-gray-300 hover:bg-gray-400 rounded-md mx-auto' onClick={previousPage} disabled={prevDisabled}>
            ⬅️ Previous
        </button>
        <button className='py-1 px-2 mx-2 bg-gray-300 hover:bg-gray-400 rounded-md mx-auto' onClick={nextPage} disabled={nextDisabled}>
          Next ➡️
        </button>
            </div>
            <div className="grid md:grid-cols-1 lg:grid-cols-1">
            {notesJSX}
            </div>
        </>
    )
}
 
export default NoteList