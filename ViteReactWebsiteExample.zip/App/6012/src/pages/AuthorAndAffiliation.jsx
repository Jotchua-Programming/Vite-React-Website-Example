import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'

function Search(author) {
  return (
      <input type="text" value={author.search} onChange={author.handleSearch} placeholder = "Search for a listing"/>
  )
}


const AuthorComponent = ({ author }) => {
  return (
    <tr key={`author_${author.contentid}`}>
      <td>{author.author_name}</td>
      <td><Link to={"" + author.doi_link} className="font-medium text-blue-600 dark:text-blue-500 hover:underline">{author.content_title}</Link></td>
      <td>{author.country}</td>
      <td>{author.city}</td>
      <td>{author.institution}</td>
      <td>{author.id}</td>
      <td>{author.content}</td>
    </tr>
  );
};

// Define the AuthorInfo component
function AuthorAndAffiliation() {
  const [Author, setAuthors] = useState([])
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [selectCountry, setSelectCountry] = useState('')
  const [selectInstitution, setSelectInstitution] = useState('')

  useEffect(() => {
    fetchData()
  }, [])

  const handleResponse = (response) => {
    if (response.status === 200) {
      return response.json()
    } else {
      throw new Error("invalid response: " + response.status)
    }
  }

  const handleJSON = (json) => {
    if (json.constructor === Array) {
      setAuthors(json)
    } else {
      throw new Error("invalid JSON: " + json)
    }
  }

  const fetchData = () => {
    fetch('HIDDENWEBPAGE/Coursework/authorinfo')
      .then((response) => handleResponse(response))
      .then((json) => handleJSON(json))
      .catch((err) => {
        console.log(err.message)
      })
  }

//checks content titles and author name against the users input, and submits values based on the closest match
const searchContentTitle = (author) => {
  const foundInContentTitle = author.content_title.toLowerCase().includes(search.toLowerCase())
  const foundInAuthorName = author.author_name.toLowerCase().includes(search.toLowerCase())
  return foundInContentTitle || foundInAuthorName
}

//if no country selected, show them all
const selectContentCountry = (author) => {
    if (selectCountry === '') {
        return true
    } else {
        return author.country === selectCountry
    }
}

//if no institution selected, show them all
const selectContentInstitution = (author) => {
  if (selectInstitution === '') {
      return true
  } else {
      return author.institution === selectInstitution
  }
}
  const startOfPage = (page - 1) * 20
  const endOfPage = startOfPage + 20

  const AuthorJSX = Author.length > 0 ? (
    Author.filter(selectContentCountry).filter(selectContentInstitution).filter(searchContentTitle)
    .slice(startOfPage, endOfPage).map(
      (author, i) => (
        <AuthorComponent key={i + author.content_title} count={i} author={author} />
      )
    )
  ) : (
    <div>
      <td>Loading...</td>
    </div>
  )

const handleSearch = (event) => {
  setSearch(event.target.value)
}

  const handleSelectCountry = (event) => {
    setSelectCountry(event.target.value)
}

const handleSelectInstitution = (event) => {
  setSelectInstitution(event.target.value)
}

  const lastPage = Author.length === 0 || AuthorJSX.length === 0; // Check for both Author and AuthorJSX
  const firstPage = page <= 1;

    // Functions to change the page
    const nextPage = () => {
      if (lastPage === false) {
          setPage( page => page + 1 )
      }
  }


  // Functions to change the page
  const previousPage = () => {
      if (firstPage === false) {
          setPage( page => page - 1 )
      }
  }

  const prevDisabled = firstPage ? 'disabled' : '';
  const nextDisabled = lastPage ? 'disabled' : '';

  const uniqueCountries = [...new Set(Author.map(({ country }) => country))].sort()
  const uniqueInstitutions = [...new Set(Author.map(({ institution }) => institution))].sort()
  return (
    <div>
            <h1>Publication List</h1>
            <button onClick={previousPage} disabled={prevDisabled} className='py-1 px-2 mx-2 bg-gray-300 hover:bg-gray-400 rounded-md mx-auto'>
        Previous
      </button>
      <button onClick={nextPage} disabled={nextDisabled} className='py-1 px-2 mx-2 bg-gray-300 hover:bg-gray-400 rounded-md mx-auto'>
        Next
      </button>
            <Search search={search} handleSearch={handleSearch} />
      <select onChange={handleSelectCountry}> 
    <option value={""}> -- Select a country -- </option>
      {uniqueCountries.map((country, index) => <option key = {index} value={country}>{country}</option>)}
    </select>

    <select onChange={handleSelectInstitution}> 
    <option value={""}> -- Select an Institution -- </option>
      {uniqueInstitutions.map((institution, index) => <option key = {index} value={institution}>{institution}</option>)}
    </select>


      <table>
        <thead>
          <tr>
            <th>Author Name</th>
            <th>Content Title</th>
            <th>Country</th>
            <th>City</th>
            <th>Institution</th>
            <th>Author ID</th>
            <th>Content ID</th>
          </tr>
        </thead>
        <tbody className='bg-white h-auto m-2 p-2 rounded-md'>{AuthorJSX}</tbody>
      </table>
    </div>
  );
}

export default AuthorAndAffiliation;